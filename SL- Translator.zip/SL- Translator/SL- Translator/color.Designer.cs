﻿
namespace SL__Translator
{
    partial class color
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(color));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.colorGreenPbx = new System.Windows.Forms.PictureBox();
            this.colorRedPbx = new System.Windows.Forms.PictureBox();
            this.colorYellowPbx = new System.Windows.Forms.PictureBox();
            this.colorBluePbx = new System.Windows.Forms.PictureBox();
            this.backBtnCp = new System.Windows.Forms.Button();
            this.nextBtnCp = new System.Windows.Forms.Button();
            this.colorBackBtn = new System.Windows.Forms.Button();
            this.colorNextBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.colorGreenPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.colorRedPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.colorYellowPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.colorBluePbx)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-5, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(629, 331);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // colorGreenPbx
            // 
            this.colorGreenPbx.Image = ((System.Drawing.Image)(resources.GetObject("colorGreenPbx.Image")));
            this.colorGreenPbx.Location = new System.Drawing.Point(461, 389);
            this.colorGreenPbx.Name = "colorGreenPbx";
            this.colorGreenPbx.Size = new System.Drawing.Size(159, 149);
            this.colorGreenPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.colorGreenPbx.TabIndex = 1;
            this.colorGreenPbx.TabStop = false;
            // 
            // colorRedPbx
            // 
            this.colorRedPbx.Image = ((System.Drawing.Image)(resources.GetObject("colorRedPbx.Image")));
            this.colorRedPbx.Location = new System.Drawing.Point(308, 389);
            this.colorRedPbx.Name = "colorRedPbx";
            this.colorRedPbx.Size = new System.Drawing.Size(159, 149);
            this.colorRedPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.colorRedPbx.TabIndex = 2;
            this.colorRedPbx.TabStop = false;
            // 
            // colorYellowPbx
            // 
            this.colorYellowPbx.Image = ((System.Drawing.Image)(resources.GetObject("colorYellowPbx.Image")));
            this.colorYellowPbx.Location = new System.Drawing.Point(0, 389);
            this.colorYellowPbx.Name = "colorYellowPbx";
            this.colorYellowPbx.Size = new System.Drawing.Size(159, 149);
            this.colorYellowPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.colorYellowPbx.TabIndex = 3;
            this.colorYellowPbx.TabStop = false;
            // 
            // colorBluePbx
            // 
            this.colorBluePbx.Image = ((System.Drawing.Image)(resources.GetObject("colorBluePbx.Image")));
            this.colorBluePbx.Location = new System.Drawing.Point(154, 389);
            this.colorBluePbx.Name = "colorBluePbx";
            this.colorBluePbx.Size = new System.Drawing.Size(159, 149);
            this.colorBluePbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.colorBluePbx.TabIndex = 4;
            this.colorBluePbx.TabStop = false;
            // 
            // backBtnCp
            // 
            this.backBtnCp.Location = new System.Drawing.Point(35, 678);
            this.backBtnCp.Name = "backBtnCp";
            this.backBtnCp.Size = new System.Drawing.Size(75, 23);
            this.backBtnCp.TabIndex = 15;
            this.backBtnCp.Text = "back";
            this.backBtnCp.UseVisualStyleBackColor = true;
            // 
            // nextBtnCp
            // 
            this.nextBtnCp.Location = new System.Drawing.Point(948, 678);
            this.nextBtnCp.Name = "nextBtnCp";
            this.nextBtnCp.Size = new System.Drawing.Size(75, 23);
            this.nextBtnCp.TabIndex = 16;
            this.nextBtnCp.Text = "next";
            this.nextBtnCp.UseVisualStyleBackColor = true;
            // 
            // colorBackBtn
            // 
            this.colorBackBtn.BackColor = System.Drawing.Color.CadetBlue;
            this.colorBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.colorBackBtn.ForeColor = System.Drawing.Color.White;
            this.colorBackBtn.Location = new System.Drawing.Point(42, 571);
            this.colorBackBtn.Name = "colorBackBtn";
            this.colorBackBtn.Size = new System.Drawing.Size(70, 33);
            this.colorBackBtn.TabIndex = 50;
            this.colorBackBtn.Text = "Back";
            this.colorBackBtn.UseVisualStyleBackColor = false;
            // 
            // colorNextBtn
            // 
            this.colorNextBtn.BackColor = System.Drawing.Color.Lime;
            this.colorNextBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.colorNextBtn.ForeColor = System.Drawing.Color.White;
            this.colorNextBtn.Location = new System.Drawing.Point(506, 571);
            this.colorNextBtn.Name = "colorNextBtn";
            this.colorNextBtn.Size = new System.Drawing.Size(70, 33);
            this.colorNextBtn.TabIndex = 49;
            this.colorNextBtn.Text = "Next";
            this.colorNextBtn.UseVisualStyleBackColor = false;
            // 
            // color
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ClientSize = new System.Drawing.Size(619, 616);
            this.Controls.Add(this.colorBackBtn);
            this.Controls.Add(this.colorNextBtn);
            this.Controls.Add(this.nextBtnCp);
            this.Controls.Add(this.backBtnCp);
            this.Controls.Add(this.colorBluePbx);
            this.Controls.Add(this.colorYellowPbx);
            this.Controls.Add(this.colorRedPbx);
            this.Controls.Add(this.colorGreenPbx);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "color";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.colorGreenPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.colorRedPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.colorYellowPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.colorBluePbx)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox colorGreenPbx;
        private System.Windows.Forms.PictureBox colorRedPbx;
        private System.Windows.Forms.PictureBox colorYellowPbx;
        private System.Windows.Forms.PictureBox colorBluePbx;
        private System.Windows.Forms.Button backBtnCp;
        private System.Windows.Forms.Button nextBtnCp;
        private System.Windows.Forms.Button colorBackBtn;
        private System.Windows.Forms.Button colorNextBtn;
    }
}