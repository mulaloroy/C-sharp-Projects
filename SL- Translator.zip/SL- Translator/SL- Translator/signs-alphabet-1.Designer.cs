﻿
namespace SL__Translator
{
    partial class signs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(signs));
            this.signAPbx = new System.Windows.Forms.PictureBox();
            this.signCPbx = new System.Windows.Forms.PictureBox();
            this.signEPbx = new System.Windows.Forms.PictureBox();
            this.signBPbx = new System.Windows.Forms.PictureBox();
            this.signDPbx = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.signsNextBtn = new System.Windows.Forms.Button();
            this.signsBackBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.signJPbx = new System.Windows.Forms.PictureBox();
            this.signHPbx = new System.Windows.Forms.PictureBox();
            this.signKPbx = new System.Windows.Forms.PictureBox();
            this.signIPbx = new System.Windows.Forms.PictureBox();
            this.signGPbx = new System.Windows.Forms.PictureBox();
            this.signFPbx = new System.Windows.Forms.PictureBox();
            this.signMPbx = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.signAPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signCPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signEPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signBPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signDPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signJPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signHPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signKPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signIPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signGPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signFPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signMPbx)).BeginInit();
            this.SuspendLayout();
            // 
            // signAPbx
            // 
            this.signAPbx.Image = ((System.Drawing.Image)(resources.GetObject("signAPbx.Image")));
            this.signAPbx.Location = new System.Drawing.Point(35, 101);
            this.signAPbx.Name = "signAPbx";
            this.signAPbx.Size = new System.Drawing.Size(104, 102);
            this.signAPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signAPbx.TabIndex = 0;
            this.signAPbx.TabStop = false;
            // 
            // signCPbx
            // 
            this.signCPbx.Image = ((System.Drawing.Image)(resources.GetObject("signCPbx.Image")));
            this.signCPbx.Location = new System.Drawing.Point(315, 51);
            this.signCPbx.Name = "signCPbx";
            this.signCPbx.Size = new System.Drawing.Size(104, 102);
            this.signCPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signCPbx.TabIndex = 1;
            this.signCPbx.TabStop = false;
            // 
            // signEPbx
            // 
            this.signEPbx.Image = ((System.Drawing.Image)(resources.GetObject("signEPbx.Image")));
            this.signEPbx.Location = new System.Drawing.Point(176, 179);
            this.signEPbx.Name = "signEPbx";
            this.signEPbx.Size = new System.Drawing.Size(104, 102);
            this.signEPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signEPbx.TabIndex = 2;
            this.signEPbx.TabStop = false;
            // 
            // signBPbx
            // 
            this.signBPbx.Image = ((System.Drawing.Image)(resources.GetObject("signBPbx.Image")));
            this.signBPbx.Location = new System.Drawing.Point(176, 51);
            this.signBPbx.Name = "signBPbx";
            this.signBPbx.Size = new System.Drawing.Size(104, 102);
            this.signBPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signBPbx.TabIndex = 3;
            this.signBPbx.TabStop = false;
            // 
            // signDPbx
            // 
            this.signDPbx.Image = ((System.Drawing.Image)(resources.GetObject("signDPbx.Image")));
            this.signDPbx.Location = new System.Drawing.Point(465, 101);
            this.signDPbx.Name = "signDPbx";
            this.signDPbx.Size = new System.Drawing.Size(104, 102);
            this.signDPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signDPbx.TabIndex = 4;
            this.signDPbx.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(886, 174);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(143, 125);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 5;
            this.pictureBox6.TabStop = false;
            // 
            // signsNextBtn
            // 
            this.signsNextBtn.BackColor = System.Drawing.Color.Lime;
            this.signsNextBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.signsNextBtn.Location = new System.Drawing.Point(499, 571);
            this.signsNextBtn.Name = "signsNextBtn";
            this.signsNextBtn.Size = new System.Drawing.Size(70, 33);
            this.signsNextBtn.TabIndex = 6;
            this.signsNextBtn.Text = "Next";
            this.signsNextBtn.UseVisualStyleBackColor = false;
            // 
            // signsBackBtn
            // 
            this.signsBackBtn.BackColor = System.Drawing.Color.CadetBlue;
            this.signsBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.signsBackBtn.Location = new System.Drawing.Point(35, 571);
            this.signsBackBtn.Name = "signsBackBtn";
            this.signsBackBtn.Size = new System.Drawing.Size(70, 33);
            this.signsBackBtn.TabIndex = 7;
            this.signsBackBtn.Text = "Back";
            this.signsBackBtn.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(15, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 33);
            this.label1.TabIndex = 8;
            this.label1.Text = "A-F";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Showcard Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(15, 319);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 33);
            this.label2.TabIndex = 9;
            this.label2.Text = "G-L";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(886, 435);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(143, 125);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 15;
            this.pictureBox7.TabStop = false;
            // 
            // signJPbx
            // 
            this.signJPbx.Image = ((System.Drawing.Image)(resources.GetObject("signJPbx.Image")));
            this.signJPbx.Location = new System.Drawing.Point(176, 483);
            this.signJPbx.Name = "signJPbx";
            this.signJPbx.Size = new System.Drawing.Size(104, 102);
            this.signJPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signJPbx.TabIndex = 14;
            this.signJPbx.TabStop = false;
            // 
            // signHPbx
            // 
            this.signHPbx.BackColor = System.Drawing.Color.Gray;
            this.signHPbx.Image = ((System.Drawing.Image)(resources.GetObject("signHPbx.Image")));
            this.signHPbx.Location = new System.Drawing.Point(176, 356);
            this.signHPbx.Name = "signHPbx";
            this.signHPbx.Size = new System.Drawing.Size(104, 102);
            this.signHPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signHPbx.TabIndex = 13;
            this.signHPbx.TabStop = false;
            // 
            // signKPbx
            // 
            this.signKPbx.Image = ((System.Drawing.Image)(resources.GetObject("signKPbx.Image")));
            this.signKPbx.Location = new System.Drawing.Point(315, 483);
            this.signKPbx.Name = "signKPbx";
            this.signKPbx.Size = new System.Drawing.Size(104, 102);
            this.signKPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signKPbx.TabIndex = 12;
            this.signKPbx.TabStop = false;
            // 
            // signIPbx
            // 
            this.signIPbx.Image = ((System.Drawing.Image)(resources.GetObject("signIPbx.Image")));
            this.signIPbx.Location = new System.Drawing.Point(315, 356);
            this.signIPbx.Name = "signIPbx";
            this.signIPbx.Size = new System.Drawing.Size(104, 102);
            this.signIPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signIPbx.TabIndex = 11;
            this.signIPbx.TabStop = false;
            // 
            // signGPbx
            // 
            this.signGPbx.Image = ((System.Drawing.Image)(resources.GetObject("signGPbx.Image")));
            this.signGPbx.Location = new System.Drawing.Point(35, 411);
            this.signGPbx.Name = "signGPbx";
            this.signGPbx.Size = new System.Drawing.Size(104, 102);
            this.signGPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signGPbx.TabIndex = 10;
            this.signGPbx.TabStop = false;
            // 
            // signFPbx
            // 
            this.signFPbx.Image = ((System.Drawing.Image)(resources.GetObject("signFPbx.Image")));
            this.signFPbx.Location = new System.Drawing.Point(315, 179);
            this.signFPbx.Name = "signFPbx";
            this.signFPbx.Size = new System.Drawing.Size(104, 102);
            this.signFPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signFPbx.TabIndex = 16;
            this.signFPbx.TabStop = false;
            // 
            // signMPbx
            // 
            this.signMPbx.Image = ((System.Drawing.Image)(resources.GetObject("signMPbx.Image")));
            this.signMPbx.Location = new System.Drawing.Point(465, 411);
            this.signMPbx.Name = "signMPbx";
            this.signMPbx.Size = new System.Drawing.Size(104, 102);
            this.signMPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signMPbx.TabIndex = 23;
            this.signMPbx.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(96, 331);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(511, 10);
            this.panel1.TabIndex = 24;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(96, 21);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(511, 10);
            this.panel2.TabIndex = 25;
            // 
            // signs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ClientSize = new System.Drawing.Size(619, 616);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.signMPbx);
            this.Controls.Add(this.signFPbx);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.signJPbx);
            this.Controls.Add(this.signHPbx);
            this.Controls.Add(this.signKPbx);
            this.Controls.Add(this.signIPbx);
            this.Controls.Add(this.signGPbx);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.signsBackBtn);
            this.Controls.Add(this.signsNextBtn);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.signDPbx);
            this.Controls.Add(this.signBPbx);
            this.Controls.Add(this.signEPbx);
            this.Controls.Add(this.signCPbx);
            this.Controls.Add(this.signAPbx);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "signs";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.signAPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signCPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signEPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signBPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signDPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signJPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signHPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signKPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signIPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signGPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signFPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signMPbx)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox signAPbx;
        private System.Windows.Forms.PictureBox signCPbx;
        private System.Windows.Forms.PictureBox signEPbx;
        private System.Windows.Forms.PictureBox signBPbx;
        private System.Windows.Forms.PictureBox signDPbx;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button signsNextBtn;
        private System.Windows.Forms.Button signsBackBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox signJPbx;
        private System.Windows.Forms.PictureBox signHPbx;
        private System.Windows.Forms.PictureBox signKPbx;
        private System.Windows.Forms.PictureBox signIPbx;
        private System.Windows.Forms.PictureBox signGPbx;
        private System.Windows.Forms.PictureBox signFPbx;
        private System.Windows.Forms.PictureBox signMPbx;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}