﻿
namespace SL__Translator
{
    partial class numbers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(numbers));
            this.number1Pbx = new System.Windows.Forms.PictureBox();
            this.number7Pbx = new System.Windows.Forms.PictureBox();
            this.number9Pbx = new System.Windows.Forms.PictureBox();
            this.number8Pbx = new System.Windows.Forms.PictureBox();
            this.number6Pbx = new System.Windows.Forms.PictureBox();
            this.number5Pbx = new System.Windows.Forms.PictureBox();
            this.number4Pbx = new System.Windows.Forms.PictureBox();
            this.number3Pbx = new System.Windows.Forms.PictureBox();
            this.number2Pbx = new System.Windows.Forms.PictureBox();
            this.number10Pbx = new System.Windows.Forms.PictureBox();
            this.backBtnCp = new System.Windows.Forms.Button();
            this.nextBtnCp = new System.Windows.Forms.Button();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.numbersBackBtn = new System.Windows.Forms.Button();
            this.numbersNextBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.number1Pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.number7Pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.number9Pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.number8Pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.number6Pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.number5Pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.number4Pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.number3Pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.number2Pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.number10Pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.SuspendLayout();
            // 
            // number1Pbx
            // 
            this.number1Pbx.Image = ((System.Drawing.Image)(resources.GetObject("number1Pbx.Image")));
            this.number1Pbx.Location = new System.Drawing.Point(72, 257);
            this.number1Pbx.Name = "number1Pbx";
            this.number1Pbx.Size = new System.Drawing.Size(111, 106);
            this.number1Pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.number1Pbx.TabIndex = 0;
            this.number1Pbx.TabStop = false;
            // 
            // number7Pbx
            // 
            this.number7Pbx.Image = ((System.Drawing.Image)(resources.GetObject("number7Pbx.Image")));
            this.number7Pbx.Location = new System.Drawing.Point(90, 498);
            this.number7Pbx.Name = "number7Pbx";
            this.number7Pbx.Size = new System.Drawing.Size(111, 106);
            this.number7Pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.number7Pbx.TabIndex = 1;
            this.number7Pbx.TabStop = false;
            // 
            // number9Pbx
            // 
            this.number9Pbx.Image = ((System.Drawing.Image)(resources.GetObject("number9Pbx.Image")));
            this.number9Pbx.Location = new System.Drawing.Point(308, 498);
            this.number9Pbx.Name = "number9Pbx";
            this.number9Pbx.Size = new System.Drawing.Size(111, 106);
            this.number9Pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.number9Pbx.TabIndex = 2;
            this.number9Pbx.TabStop = false;
            // 
            // number8Pbx
            // 
            this.number8Pbx.Image = ((System.Drawing.Image)(resources.GetObject("number8Pbx.Image")));
            this.number8Pbx.Location = new System.Drawing.Point(201, 498);
            this.number8Pbx.Name = "number8Pbx";
            this.number8Pbx.Size = new System.Drawing.Size(111, 106);
            this.number8Pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.number8Pbx.TabIndex = 3;
            this.number8Pbx.TabStop = false;
            // 
            // number6Pbx
            // 
            this.number6Pbx.Image = ((System.Drawing.Image)(resources.GetObject("number6Pbx.Image")));
            this.number6Pbx.Location = new System.Drawing.Point(472, 359);
            this.number6Pbx.Name = "number6Pbx";
            this.number6Pbx.Size = new System.Drawing.Size(111, 106);
            this.number6Pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.number6Pbx.TabIndex = 4;
            this.number6Pbx.TabStop = false;
            this.number6Pbx.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // number5Pbx
            // 
            this.number5Pbx.Image = ((System.Drawing.Image)(resources.GetObject("number5Pbx.Image")));
            this.number5Pbx.Location = new System.Drawing.Point(370, 359);
            this.number5Pbx.Name = "number5Pbx";
            this.number5Pbx.Size = new System.Drawing.Size(111, 106);
            this.number5Pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.number5Pbx.TabIndex = 5;
            this.number5Pbx.TabStop = false;
            // 
            // number4Pbx
            // 
            this.number4Pbx.Image = ((System.Drawing.Image)(resources.GetObject("number4Pbx.Image")));
            this.number4Pbx.Location = new System.Drawing.Point(424, 257);
            this.number4Pbx.Name = "number4Pbx";
            this.number4Pbx.Size = new System.Drawing.Size(111, 106);
            this.number4Pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.number4Pbx.TabIndex = 6;
            this.number4Pbx.TabStop = false;
            // 
            // number3Pbx
            // 
            this.number3Pbx.Image = ((System.Drawing.Image)(resources.GetObject("number3Pbx.Image")));
            this.number3Pbx.Location = new System.Drawing.Point(128, 359);
            this.number3Pbx.Name = "number3Pbx";
            this.number3Pbx.Size = new System.Drawing.Size(111, 106);
            this.number3Pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.number3Pbx.TabIndex = 7;
            this.number3Pbx.TabStop = false;
            // 
            // number2Pbx
            // 
            this.number2Pbx.Image = ((System.Drawing.Image)(resources.GetObject("number2Pbx.Image")));
            this.number2Pbx.Location = new System.Drawing.Point(22, 359);
            this.number2Pbx.Name = "number2Pbx";
            this.number2Pbx.Size = new System.Drawing.Size(111, 106);
            this.number2Pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.number2Pbx.TabIndex = 8;
            this.number2Pbx.TabStop = false;
            // 
            // number10Pbx
            // 
            this.number10Pbx.Image = ((System.Drawing.Image)(resources.GetObject("number10Pbx.Image")));
            this.number10Pbx.Location = new System.Drawing.Point(417, 498);
            this.number10Pbx.Name = "number10Pbx";
            this.number10Pbx.Size = new System.Drawing.Size(111, 106);
            this.number10Pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.number10Pbx.TabIndex = 9;
            this.number10Pbx.TabStop = false;
            // 
            // backBtnCp
            // 
            this.backBtnCp.Location = new System.Drawing.Point(25, 693);
            this.backBtnCp.Name = "backBtnCp";
            this.backBtnCp.Size = new System.Drawing.Size(75, 23);
            this.backBtnCp.TabIndex = 15;
            this.backBtnCp.Text = "back";
            this.backBtnCp.UseVisualStyleBackColor = true;
            // 
            // nextBtnCp
            // 
            this.nextBtnCp.Location = new System.Drawing.Point(959, 693);
            this.nextBtnCp.Name = "nextBtnCp";
            this.nextBtnCp.Size = new System.Drawing.Size(75, 23);
            this.nextBtnCp.TabIndex = 16;
            this.nextBtnCp.Text = "next";
            this.nextBtnCp.UseVisualStyleBackColor = true;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::SL__Translator.Properties.Resources.num;
            this.pictureBox11.Location = new System.Drawing.Point(2, -2);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(615, 243);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 17;
            this.pictureBox11.TabStop = false;
            // 
            // numbersBackBtn
            // 
            this.numbersBackBtn.BackColor = System.Drawing.Color.CadetBlue;
            this.numbersBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.numbersBackBtn.ForeColor = System.Drawing.Color.White;
            this.numbersBackBtn.Location = new System.Drawing.Point(12, 571);
            this.numbersBackBtn.Name = "numbersBackBtn";
            this.numbersBackBtn.Size = new System.Drawing.Size(70, 33);
            this.numbersBackBtn.TabIndex = 50;
            this.numbersBackBtn.Text = "Back";
            this.numbersBackBtn.UseVisualStyleBackColor = false;
            // 
            // numbersNextBtn
            // 
            this.numbersNextBtn.BackColor = System.Drawing.Color.Lime;
            this.numbersNextBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.numbersNextBtn.ForeColor = System.Drawing.Color.White;
            this.numbersNextBtn.Location = new System.Drawing.Point(537, 571);
            this.numbersNextBtn.Name = "numbersNextBtn";
            this.numbersNextBtn.Size = new System.Drawing.Size(70, 33);
            this.numbersNextBtn.TabIndex = 49;
            this.numbersNextBtn.Text = "Next";
            this.numbersNextBtn.UseVisualStyleBackColor = false;
            // 
            // numbers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ClientSize = new System.Drawing.Size(619, 616);
            this.Controls.Add(this.numbersBackBtn);
            this.Controls.Add(this.numbersNextBtn);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.nextBtnCp);
            this.Controls.Add(this.backBtnCp);
            this.Controls.Add(this.number10Pbx);
            this.Controls.Add(this.number2Pbx);
            this.Controls.Add(this.number3Pbx);
            this.Controls.Add(this.number4Pbx);
            this.Controls.Add(this.number5Pbx);
            this.Controls.Add(this.number6Pbx);
            this.Controls.Add(this.number8Pbx);
            this.Controls.Add(this.number9Pbx);
            this.Controls.Add(this.number7Pbx);
            this.Controls.Add(this.number1Pbx);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "numbers";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.number1Pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.number7Pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.number9Pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.number8Pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.number6Pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.number5Pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.number4Pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.number3Pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.number2Pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.number10Pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox number1Pbx;
        private System.Windows.Forms.PictureBox number7Pbx;
        private System.Windows.Forms.PictureBox number9Pbx;
        private System.Windows.Forms.PictureBox number8Pbx;
        private System.Windows.Forms.PictureBox number6Pbx;
        private System.Windows.Forms.PictureBox number5Pbx;
        private System.Windows.Forms.PictureBox number4Pbx;
        private System.Windows.Forms.PictureBox number3Pbx;
        private System.Windows.Forms.PictureBox number2Pbx;
        private System.Windows.Forms.PictureBox number10Pbx;
        private System.Windows.Forms.Button backBtnCp;
        private System.Windows.Forms.Button nextBtnCp;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Button numbersBackBtn;
        private System.Windows.Forms.Button numbersNextBtn;
    }
}