﻿
namespace SL__Translator
{
    partial class signs2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(signs2));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.signPPbx = new System.Windows.Forms.PictureBox();
            this.signNPbx = new System.Windows.Forms.PictureBox();
            this.signQPbx = new System.Windows.Forms.PictureBox();
            this.signOPbx = new System.Windows.Forms.PictureBox();
            this.signXPbx = new System.Windows.Forms.PictureBox();
            this.signVPbx = new System.Windows.Forms.PictureBox();
            this.signTPbx = new System.Windows.Forms.PictureBox();
            this.signWPbx = new System.Windows.Forms.PictureBox();
            this.signUPbx = new System.Windows.Forms.PictureBox();
            this.signSPbx = new System.Windows.Forms.PictureBox();
            this.signYPbx = new System.Windows.Forms.PictureBox();
            this.signZPbx = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.signRPbx = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.signs2BackBtn = new System.Windows.Forms.Button();
            this.signs2NextBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signPPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signNPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signQPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signOPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signXPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signVPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signTPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signWPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signUPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signSPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signYPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signZPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signRPbx)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Lime;
            this.button1.Location = new System.Drawing.Point(906, 694);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(143, 33);
            this.button1.TabIndex = 7;
            this.button1.Text = "Next";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Yellow;
            this.button2.Location = new System.Drawing.Point(29, 683);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(143, 33);
            this.button2.TabIndex = 8;
            this.button2.Text = "Back";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(879, 82);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(143, 125);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 27;
            this.pictureBox13.TabStop = false;
            // 
            // signPPbx
            // 
            this.signPPbx.Image = ((System.Drawing.Image)(resources.GetObject("signPPbx.Image")));
            this.signPPbx.Location = new System.Drawing.Point(307, 45);
            this.signPPbx.Name = "signPPbx";
            this.signPPbx.Size = new System.Drawing.Size(108, 102);
            this.signPPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signPPbx.TabIndex = 26;
            this.signPPbx.TabStop = false;
            // 
            // signNPbx
            // 
            this.signNPbx.Image = ((System.Drawing.Image)(resources.GetObject("signNPbx.Image")));
            this.signNPbx.Location = new System.Drawing.Point(79, 45);
            this.signNPbx.Name = "signNPbx";
            this.signNPbx.Size = new System.Drawing.Size(108, 102);
            this.signNPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signNPbx.TabIndex = 25;
            this.signNPbx.TabStop = false;
            // 
            // signQPbx
            // 
            this.signQPbx.Image = ((System.Drawing.Image)(resources.GetObject("signQPbx.Image")));
            this.signQPbx.Location = new System.Drawing.Point(421, 45);
            this.signQPbx.Name = "signQPbx";
            this.signQPbx.Size = new System.Drawing.Size(108, 102);
            this.signQPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signQPbx.TabIndex = 24;
            this.signQPbx.TabStop = false;
            // 
            // signOPbx
            // 
            this.signOPbx.Image = ((System.Drawing.Image)(resources.GetObject("signOPbx.Image")));
            this.signOPbx.Location = new System.Drawing.Point(193, 45);
            this.signOPbx.Name = "signOPbx";
            this.signOPbx.Size = new System.Drawing.Size(108, 102);
            this.signOPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signOPbx.TabIndex = 23;
            this.signOPbx.TabStop = false;
            // 
            // signXPbx
            // 
            this.signXPbx.Image = ((System.Drawing.Image)(resources.GetObject("signXPbx.Image")));
            this.signXPbx.Location = new System.Drawing.Point(193, 435);
            this.signXPbx.Name = "signXPbx";
            this.signXPbx.Size = new System.Drawing.Size(108, 102);
            this.signXPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signXPbx.TabIndex = 33;
            this.signXPbx.TabStop = false;
            // 
            // signVPbx
            // 
            this.signVPbx.Image = ((System.Drawing.Image)(resources.GetObject("signVPbx.Image")));
            this.signVPbx.Location = new System.Drawing.Point(480, 225);
            this.signVPbx.Name = "signVPbx";
            this.signVPbx.Size = new System.Drawing.Size(108, 102);
            this.signVPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signVPbx.TabIndex = 32;
            this.signVPbx.TabStop = false;
            // 
            // signTPbx
            // 
            this.signTPbx.Image = ((System.Drawing.Image)(resources.GetObject("signTPbx.Image")));
            this.signTPbx.Location = new System.Drawing.Point(252, 225);
            this.signTPbx.Name = "signTPbx";
            this.signTPbx.Size = new System.Drawing.Size(108, 102);
            this.signTPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signTPbx.TabIndex = 31;
            this.signTPbx.TabStop = false;
            // 
            // signWPbx
            // 
            this.signWPbx.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.signWPbx.Image = ((System.Drawing.Image)(resources.GetObject("signWPbx.Image")));
            this.signWPbx.Location = new System.Drawing.Point(87, 435);
            this.signWPbx.Name = "signWPbx";
            this.signWPbx.Size = new System.Drawing.Size(100, 102);
            this.signWPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signWPbx.TabIndex = 30;
            this.signWPbx.TabStop = false;
            // 
            // signUPbx
            // 
            this.signUPbx.Image = ((System.Drawing.Image)(resources.GetObject("signUPbx.Image")));
            this.signUPbx.Location = new System.Drawing.Point(366, 225);
            this.signUPbx.Name = "signUPbx";
            this.signUPbx.Size = new System.Drawing.Size(108, 102);
            this.signUPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signUPbx.TabIndex = 29;
            this.signUPbx.TabStop = false;
            // 
            // signSPbx
            // 
            this.signSPbx.Image = ((System.Drawing.Image)(resources.GetObject("signSPbx.Image")));
            this.signSPbx.Location = new System.Drawing.Point(138, 225);
            this.signSPbx.Name = "signSPbx";
            this.signSPbx.Size = new System.Drawing.Size(108, 102);
            this.signSPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signSPbx.TabIndex = 28;
            this.signSPbx.TabStop = false;
            // 
            // signYPbx
            // 
            this.signYPbx.Image = ((System.Drawing.Image)(resources.GetObject("signYPbx.Image")));
            this.signYPbx.Location = new System.Drawing.Point(307, 435);
            this.signYPbx.Name = "signYPbx";
            this.signYPbx.Size = new System.Drawing.Size(108, 102);
            this.signYPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signYPbx.TabIndex = 36;
            this.signYPbx.TabStop = false;
            // 
            // signZPbx
            // 
            this.signZPbx.Image = ((System.Drawing.Image)(resources.GetObject("signZPbx.Image")));
            this.signZPbx.Location = new System.Drawing.Point(421, 435);
            this.signZPbx.Name = "signZPbx";
            this.signZPbx.Size = new System.Drawing.Size(108, 102);
            this.signZPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signZPbx.TabIndex = 37;
            this.signZPbx.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Showcard Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(277, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 33);
            this.label4.TabIndex = 39;
            this.label4.Text = "N-S";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(277, 388);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 33);
            this.label1.TabIndex = 41;
            this.label1.Text = "W-Z";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Showcard Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(277, 173);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 33);
            this.label2.TabIndex = 42;
            this.label2.Text = "R-V";
            // 
            // signRPbx
            // 
            this.signRPbx.Image = ((System.Drawing.Image)(resources.GetObject("signRPbx.Image")));
            this.signRPbx.Location = new System.Drawing.Point(24, 225);
            this.signRPbx.Name = "signRPbx";
            this.signRPbx.Size = new System.Drawing.Size(108, 102);
            this.signRPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.signRPbx.TabIndex = 43;
            this.signRPbx.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(8, 160);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(599, 10);
            this.panel1.TabIndex = 45;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(7, 375);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(599, 10);
            this.panel2.TabIndex = 46;
            // 
            // signs2BackBtn
            // 
            this.signs2BackBtn.BackColor = System.Drawing.Color.CadetBlue;
            this.signs2BackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.signs2BackBtn.ForeColor = System.Drawing.Color.White;
            this.signs2BackBtn.Location = new System.Drawing.Point(32, 571);
            this.signs2BackBtn.Name = "signs2BackBtn";
            this.signs2BackBtn.Size = new System.Drawing.Size(70, 33);
            this.signs2BackBtn.TabIndex = 48;
            this.signs2BackBtn.Text = "Back";
            this.signs2BackBtn.UseVisualStyleBackColor = false;
            // 
            // signs2NextBtn
            // 
            this.signs2NextBtn.BackColor = System.Drawing.Color.Lime;
            this.signs2NextBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.signs2NextBtn.ForeColor = System.Drawing.Color.White;
            this.signs2NextBtn.Location = new System.Drawing.Point(496, 571);
            this.signs2NextBtn.Name = "signs2NextBtn";
            this.signs2NextBtn.Size = new System.Drawing.Size(70, 33);
            this.signs2NextBtn.TabIndex = 47;
            this.signs2NextBtn.Text = "Next";
            this.signs2NextBtn.UseVisualStyleBackColor = false;
            // 
            // signs2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ClientSize = new System.Drawing.Size(619, 616);
            this.Controls.Add(this.signs2BackBtn);
            this.Controls.Add(this.signs2NextBtn);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.signRPbx);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.signZPbx);
            this.Controls.Add(this.signYPbx);
            this.Controls.Add(this.signXPbx);
            this.Controls.Add(this.signVPbx);
            this.Controls.Add(this.signTPbx);
            this.Controls.Add(this.signWPbx);
            this.Controls.Add(this.signUPbx);
            this.Controls.Add(this.signSPbx);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.signPPbx);
            this.Controls.Add(this.signNPbx);
            this.Controls.Add(this.signQPbx);
            this.Controls.Add(this.signOPbx);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "signs2";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signPPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signNPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signQPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signOPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signXPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signVPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signTPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signWPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signUPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signSPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signYPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signZPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signRPbx)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox signPPbx;
        private System.Windows.Forms.PictureBox signNPbx;
        private System.Windows.Forms.PictureBox signQPbx;
        private System.Windows.Forms.PictureBox signOPbx;
        private System.Windows.Forms.PictureBox signXPbx;
        private System.Windows.Forms.PictureBox signVPbx;
        private System.Windows.Forms.PictureBox signTPbx;
        private System.Windows.Forms.PictureBox signWPbx;
        private System.Windows.Forms.PictureBox signUPbx;
        private System.Windows.Forms.PictureBox signSPbx;
        private System.Windows.Forms.PictureBox signYPbx;
        private System.Windows.Forms.PictureBox signZPbx;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox signRPbx;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button signs2BackBtn;
        private System.Windows.Forms.Button signs2NextBtn;
    }
}