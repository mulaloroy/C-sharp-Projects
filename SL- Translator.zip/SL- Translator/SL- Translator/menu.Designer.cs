﻿
namespace SL__Translator
{
    partial class menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(menu));
            this.menuQuizPbx = new System.Windows.Forms.PictureBox();
            this.quizBtn = new System.Windows.Forms.Button();
            this.menuColorPbx = new System.Windows.Forms.PictureBox();
            this.menuVowelsPbx = new System.Windows.Forms.PictureBox();
            this.menuAlphabetPbx = new System.Windows.Forms.PictureBox();
            this.menuNumbersPbx = new System.Windows.Forms.PictureBox();
            this.menuBackBtn = new System.Windows.Forms.Button();
            this.menuNextBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.menuQuizPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuColorPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuVowelsPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuAlphabetPbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuNumbersPbx)).BeginInit();
            this.SuspendLayout();
            // 
            // menuQuizPbx
            // 
            this.menuQuizPbx.Image = ((System.Drawing.Image)(resources.GetObject("menuQuizPbx.Image")));
            this.menuQuizPbx.Location = new System.Drawing.Point(208, 434);
            this.menuQuizPbx.Name = "menuQuizPbx";
            this.menuQuizPbx.Size = new System.Drawing.Size(211, 170);
            this.menuQuizPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.menuQuizPbx.TabIndex = 2;
            this.menuQuizPbx.TabStop = false;
            // 
            // quizBtn
            // 
            this.quizBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(83)))), ((int)(((byte)(133)))));
            this.quizBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quizBtn.ForeColor = System.Drawing.Color.White;
            this.quizBtn.Location = new System.Drawing.Point(1077, 767);
            this.quizBtn.Name = "quizBtn";
            this.quizBtn.Size = new System.Drawing.Size(1077, 767);
            this.quizBtn.TabIndex = 3;
            this.quizBtn.Text = "QUIZ";
            this.quizBtn.UseVisualStyleBackColor = false;
            // 
            // menuColorPbx
            // 
            this.menuColorPbx.Image = ((System.Drawing.Image)(resources.GetObject("menuColorPbx.Image")));
            this.menuColorPbx.Location = new System.Drawing.Point(335, 31);
            this.menuColorPbx.Name = "menuColorPbx";
            this.menuColorPbx.Size = new System.Drawing.Size(211, 170);
            this.menuColorPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.menuColorPbx.TabIndex = 4;
            this.menuColorPbx.TabStop = false;
            this.menuColorPbx.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // menuVowelsPbx
            // 
            this.menuVowelsPbx.Image = ((System.Drawing.Image)(resources.GetObject("menuVowelsPbx.Image")));
            this.menuVowelsPbx.Location = new System.Drawing.Point(75, 31);
            this.menuVowelsPbx.Name = "menuVowelsPbx";
            this.menuVowelsPbx.Size = new System.Drawing.Size(211, 170);
            this.menuVowelsPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.menuVowelsPbx.TabIndex = 33;
            this.menuVowelsPbx.TabStop = false;
            // 
            // menuAlphabetPbx
            // 
            this.menuAlphabetPbx.Image = ((System.Drawing.Image)(resources.GetObject("menuAlphabetPbx.Image")));
            this.menuAlphabetPbx.Location = new System.Drawing.Point(335, 224);
            this.menuAlphabetPbx.Name = "menuAlphabetPbx";
            this.menuAlphabetPbx.Size = new System.Drawing.Size(211, 170);
            this.menuAlphabetPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.menuAlphabetPbx.TabIndex = 34;
            this.menuAlphabetPbx.TabStop = false;
            // 
            // menuNumbersPbx
            // 
            this.menuNumbersPbx.Image = ((System.Drawing.Image)(resources.GetObject("menuNumbersPbx.Image")));
            this.menuNumbersPbx.Location = new System.Drawing.Point(75, 224);
            this.menuNumbersPbx.Name = "menuNumbersPbx";
            this.menuNumbersPbx.Size = new System.Drawing.Size(211, 170);
            this.menuNumbersPbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.menuNumbersPbx.TabIndex = 35;
            this.menuNumbersPbx.TabStop = false;
            // 
            // menuBackBtn
            // 
            this.menuBackBtn.BackColor = System.Drawing.Color.CadetBlue;
            this.menuBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.menuBackBtn.ForeColor = System.Drawing.Color.White;
            this.menuBackBtn.Location = new System.Drawing.Point(43, 571);
            this.menuBackBtn.Name = "menuBackBtn";
            this.menuBackBtn.Size = new System.Drawing.Size(70, 33);
            this.menuBackBtn.TabIndex = 50;
            this.menuBackBtn.Text = "Log Out";
            this.menuBackBtn.UseVisualStyleBackColor = false;
            // 
            // menuNextBtn
            // 
            this.menuNextBtn.BackColor = System.Drawing.Color.Lime;
            this.menuNextBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.menuNextBtn.ForeColor = System.Drawing.Color.White;
            this.menuNextBtn.Location = new System.Drawing.Point(507, 571);
            this.menuNextBtn.Name = "menuNextBtn";
            this.menuNextBtn.Size = new System.Drawing.Size(70, 33);
            this.menuNextBtn.TabIndex = 49;
            this.menuNextBtn.Text = "Next";
            this.menuNextBtn.UseVisualStyleBackColor = false;
            this.menuNextBtn.Visible = false;
            this.menuNextBtn.Click += new System.EventHandler(this.menuNextBtn_Click);
            // 
            // menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ClientSize = new System.Drawing.Size(619, 616);
            this.Controls.Add(this.menuBackBtn);
            this.Controls.Add(this.menuNextBtn);
            this.Controls.Add(this.menuNumbersPbx);
            this.Controls.Add(this.menuAlphabetPbx);
            this.Controls.Add(this.menuVowelsPbx);
            this.Controls.Add(this.menuColorPbx);
            this.Controls.Add(this.quizBtn);
            this.Controls.Add(this.menuQuizPbx);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "menu";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.menuQuizPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuColorPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuVowelsPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuAlphabetPbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuNumbersPbx)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox menuQuizPbx;
        private System.Windows.Forms.Button quizBtn;
        private System.Windows.Forms.PictureBox menuColorPbx;
        private System.Windows.Forms.PictureBox menuVowelsPbx;
        private System.Windows.Forms.PictureBox menuAlphabetPbx;
        private System.Windows.Forms.PictureBox menuNumbersPbx;
        private System.Windows.Forms.Button menuBackBtn;
        private System.Windows.Forms.Button menuNextBtn;
    }
}